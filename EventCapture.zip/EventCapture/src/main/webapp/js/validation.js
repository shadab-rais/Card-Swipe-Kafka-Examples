 
function validateform()
{       
	if(document.frm.empid.value=="")
    {
      alert("Employee id should not be blank");
      document.frm.empid.focus();
      return false;
    }

	
	    if(document.frm.name.value=="")
	    {
	      alert("Employee Name should not be left blank");
	      document.frm.name.focus();
	      return false;
	    }
	    else if(document.frm.mob.value=="")
	    {
	      alert("Mob should not be left blank");
	      document.frm.mob.focus();
	      return false;
	    }
	}
 