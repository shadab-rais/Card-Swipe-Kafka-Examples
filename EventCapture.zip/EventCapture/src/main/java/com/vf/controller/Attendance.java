package com.vf.controller;

import com.vf.business.NewUserBean;
import com.vf.dao.NewUserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.vf.business.AttendanceBean;
import com.vf.dao.AttendanceDAO;
import java.text.*;
import java.util.Date;
/**
 *
 * @author shadab rais
 */
@WebServlet(name = "Attendance", urlPatterns = {"/Attendance"})
public class Attendance extends HttpServlet {
	
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private String date = sdf.format(new Date());
   
    SimpleDateFormat stf = new SimpleDateFormat("HH:mm");
    private String time = stf.format(new Date());
    

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, java.io.IOException {
    	
    	
    	
    	     
    	     
    	     String id = request.getParameter("empid");
    	     
             AttendanceBean attnd = new AttendanceBean();
           
             attnd.setEmpId(id);
             attnd.setDate(date);
             attnd.setTime(time);
             
             
             attnd = AttendanceDAO.addempattnd(attnd);
          if (attnd.isValid()) {
                 response.sendRedirect("attendencechecking.jsp");
                 }     
            

        
    }
}
