
package com.vf.controller;

import com.vf.business.UserBean;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vf.business.NewUserBean;
import com.vf.dao.NewUserDAO;

/**
 *
 * @author shadab rais
 */
@WebServlet(name = "NewUser", urlPatterns = {"/NewUser"})
public class NewUser extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, java.io.IOException {
        try {
            String id = request.getParameter("empid");
            String name = request.getParameter("name");
            String mob = request.getParameter("mob");

            NewUserBean user = new NewUserBean();
            user.setEmpId(id);
            user.setEmpName(name);
            user.setMobNO(mob);


            user = NewUserDAO.adduser(user);
            if (user.isValid()) {
            response.sendRedirect("useradded.jsp");  
            }else{
                response.sendRedirect("nonewuser.jsp");
            }            

        } catch (Throwable theException) {
            System.out.println(theException);
        }
    }

}
