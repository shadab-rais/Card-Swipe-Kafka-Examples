
package com.vf.business;

/**
 *
 * @author shadab rais
 */
public class AttendanceBean {
    private String empId;
    private String dt;
    private String time;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getDt() {
		return dt;
	}
	public void setDate(String dt) {
		this.dt = dt;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	public boolean valid;
    
}
