package com.vf.producer;

//import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
//import org.apache.kafka.clients.producer.RecordMetadata;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.Scanner;


public class SampleProducer extends Thread {
	private final KafkaProducer<Integer, String> producer;
	private final String topic;
	private final Boolean isAsync;

	public static final String KAFKA_SERVER_URL = "localhost";
	public static final int KAFKA_SERVER_PORT = 9092;
	public static final String CLIENT_ID = "SampleProducer";

	public SampleProducer(String topic, Boolean isAsync) {
		Properties properties = new Properties();
		properties.put("bootstrap.servers", KAFKA_SERVER_URL + ":" + KAFKA_SERVER_PORT);
		properties.put("client.id", CLIENT_ID);
		properties.put("key.serializer", "org.apache.kafka.common.serialization.IntegerSerializer");
		properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		producer = new KafkaProducer<>(properties);
		this.topic = topic;
		this.isAsync = isAsync;
	}

	public void run() {
		char ans= 'Y';
		
	          System.out.println("Swipe your card Here ");
		while (ans == 'Y' || ans == 'y') {
			
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Employee_id/in or Employee_id/out for swipe_in or swipe_out respectively : like(sr0001/in) ");
			String topicmsg =sc.next();
			
			
			
			//String messageStr = "empid";
			//long startTime = System.currentTimeMillis();
			if (isAsync) { // Send asynchronously
				producer.send(new ProducerRecord<>(topic,
						
						topicmsg));
			} else { // Send synchronously
				try {
					producer.send(new ProducerRecord<>(topic,
						
							topicmsg)).get();
					System.out.println("Sent message: ("  + topicmsg +")");
				} catch (InterruptedException | ExecutionException e) {
					e.printStackTrace();
					// handle the exception
				}
			}
		//	System.out.println("Enter Employee Id (Y/N)");
	     //		sc.next();
		}
	}
}

