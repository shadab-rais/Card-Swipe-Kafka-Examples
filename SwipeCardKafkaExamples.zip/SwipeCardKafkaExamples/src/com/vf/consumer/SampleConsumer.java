package com.vf.consumer;

import kafka.utils.ShutdownableThread;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.util.Collections;
import java.util.Date;
import java.util.Properties;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;


import com.vf.utility.ConnectionManager;



public class SampleConsumer extends ShutdownableThread {
	static Connection currentCon = null;
    static ResultSet rs = null;

	Statement stmt = null;
    private final KafkaConsumer<Integer, String> consumer;
    private final String topic;
    
	public static final String KAFKA_SERVER_URL = "localhost";
	public static final int KAFKA_SERVER_PORT = 9092;
	public static final String CLIENT_ID = "SampleConsumer";

    public SampleConsumer(String topic) {
        super("KafkaConsumerExample", false);
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA_SERVER_URL + ":" + KAFKA_SERVER_PORT);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, CLIENT_ID);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.IntegerDeserializer");
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");

        consumer = new KafkaConsumer<>(props);
        this.topic = topic;
    }

    @Override
    public void doWork() {
        consumer.subscribe(Collections.singletonList(this.topic));
        ConsumerRecords<Integer, String> records = consumer.poll(1000);
        
        for (ConsumerRecord<Integer, String> record : records) {
        	
        	String s = record.value();
        	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
             String today = sdf.format(new Date());
            
             
            SimpleDateFormat stf = new SimpleDateFormat("HH:mm");
            String time = stf.format(new Date());
          
          
            
            if(s.substring(s.indexOf('/')+1).equals("in")){
            
            String searchQuery = "INSERT INTO modatt (Employee_id , Date_of_swipe , Time_of_swipein ,Time_of_swipeout)"
            + " VALUES (?,?,?,?)";
        	
            try {
            	
                currentCon = ConnectionManager.getConnection();
                PreparedStatement preparedStatement = null;
                
                preparedStatement = currentCon.prepareStatement(searchQuery);
                preparedStatement.setString(1,s.substring(0,s.indexOf('/')));
                preparedStatement.setString(2,today);
               
                preparedStatement.setString(3, time);
                preparedStatement.setString(4, " ");
            
                

                 preparedStatement.executeUpdate();
            } catch (SQLException e) {
                System.out.println("Error executing " + searchQuery + " statement: "
                        + e.getMessage());
                //return 0;
            } 
            finally {

                if (stmt != null) {
                    try {
                        stmt.close();
                    } catch (Exception e) {
                    	
                    }
                    stmt = null;
                }

                if (currentCon != null) {
                    try {
                        currentCon.close();
                    } catch (Exception e) {
                    }

                    currentCon = null;
                }
            }
            System.out.println("Received message: (" + record.key() + ", " + record.value() + ")");
        }
            
            
          
            else if (s.substring(s.indexOf('/')+1).equals("out")){
            
            	String query = "update modatt set Time_of_swipeout ='"+time+"'where Time_of_swipeout ='"+" "+"' and Employee_id ='"+s.substring(0,s.indexOf('/'))+"' ";
            	try{
            		currentCon = ConnectionManager.getConnection();
                    PreparedStatement preparedStatement = null;
                    
                    preparedStatement = currentCon.prepareStatement(query);
                     preparedStatement.executeUpdate();
                    
                } catch (SQLException e) {
                    System.out.println("Error executing " + query + " statement: "
                            + e.getMessage());
                    //return 0;
                } 
                finally {

                    if (stmt != null) {
                        try {
                            stmt.close();
                        } catch (Exception e) {
                        	
                        }
                        stmt = null;
                    }

                    if (currentCon != null) {
                        try {
                            currentCon.close();
                        } catch (Exception e) {
                        }

                        currentCon = null;
                    }
                }
                System.out.println("Received message: (" + record.key() + ", " + record.value() + ")");
            }

             
            	}
        }
    
    
    
    	
   
/*
    @Override
    public String name() {
        return null;
    }

    @Override
    public boolean isInterruptible() {
        return false;
    }*/
}
